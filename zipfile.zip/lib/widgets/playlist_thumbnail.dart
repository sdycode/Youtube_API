import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:yt1/Providers/provider.dart';

import 'package:yt1/Utils/sizes.dart';

import 'package:yt1/models/playlist_model.dart';


class PlaylistThumbnail extends StatefulWidget {
  int no;
  PlaylistThumbnail(this.no, {Key? key}) : super(key: key);

  @override
  State<PlaylistThumbnail> createState() => _PlaylistThumbnailState();
}

class _PlaylistThumbnailState extends State<PlaylistThumbnail> {
  double h = Sizes().sh;
  double w = Sizes().sw;
  late VideoProvider vp;
  @override
  Widget build(BuildContext context) {
    vp = Provider.of<VideoProvider>(context);
    PlaylistInfoModel model = vp.plListList[widget.no];
    return ClipRRect(
      borderRadius: BorderRadius.circular(w * 0.05),
      // clipBehavior: Clip.hardEdge,
      child: Container(
        // height: h * 0.18,
        width: w,

        margin: EdgeInsets.all(w * 0.05),
        decoration: BoxDecoration(
          color: Colors.orange.shade100,
          borderRadius: BorderRadius.circular(w * 0.05),
        ),

        child: ClipRRect(
          borderRadius: BorderRadius.circular(w * 0.05),
          // clipBehavior: Clip.hardEdge,
          child: Column(
            children: [
              Center(
                  child: Text(
                model.title,
                textAlign: TextAlign.center,
                style:
                    TextStyle(fontSize: w * 0.05, fontWeight: FontWeight.w800),
              )),
              Container(
                width: w * 0.9,
                height: h * 0.15,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      // decoration: BoxDecoration(
                      //         borderRadius: BorderRadius.circular(w * 0.05), border: Border.all()),

                      height: h * 0.15,
                      width: h * 0.15 * 4 / 3,
                      child: Image.network(model.imgUrl),
                    ),
                    Container(
                      // color: Colors.amber,
                      width: w * 0.89 - h * 0.15 * 4 / 3,
                      child: Text(
                        model.channelName,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: w * 0.05,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              model.description == ''
                  ? Container()
                  : Container(
                      // height: h*0.03,
                      width: w * 0.9,
                      child: Text(
                        model.description,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: w * 0.03,
                        ),
                      ),
                    )
            ],
          ),
        ),
      ),
    );
  }
}
