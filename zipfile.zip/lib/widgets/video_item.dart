import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class VideoItem extends StatefulWidget {
  int videoNo;
  String title;
  String imgurl;

  String duration;
  String videoId;
  VideoItem({
    Key? key,
    required this.videoNo,
    required this.title,
    required this.imgurl,
    required this.duration,
    required this.videoId
  }) : super(key: key);

  @override
  _VideoItemState createState() => _VideoItemState();
}

class _VideoItemState extends State<VideoItem> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(19),
        ),
        elevation: 6,
        child: Column(children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: SizedBox(
                height: 50,
                child: Text(
                  widget.title,
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                )),
          ),
          Container(
            width: MediaQuery.of(context).size.width * 0.9,
            height: 80,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Stack(
                  alignment: Alignment.center,
                  children: [
                    Icon(
                      Icons.circle,
                      color: Colors.indigo,
                      size: 35,
                    ),
                    Text(
                      widget.videoNo.toString(),
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 20, color: Colors.white),
                    ),
                  ],
                ),
                SizedBox(
                    width: MediaQuery.of(context).size.width * 0.4,
                    child: Image.network(
                      widget.imgurl,
                      fit: BoxFit.cover,
                    )),
                Container(
                  child: Center(
                      child: Text(
                    widget.duration,
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                  )),
                )
              ],
            ),
          ),
          // Text(widget.title),
          SizedBox(
            height: 10,
          )
        ]),
      ),
    );
  }
}
