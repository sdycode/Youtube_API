import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:yt1/Providers/provider.dart';
import 'package:yt1/Utils/constants.dart';
import 'package:yt1/Utils/round_no.dart';

class VideoBarChartWidget extends StatefulWidget {
  int index;
  double h;
  double w;
  VideoBarChartWidget(this.index, this.h, this.w);

  @override
  State<VideoBarChartWidget> createState() => _VideoBarChartWidgetState();
}

class _VideoBarChartWidgetState extends State<VideoBarChartWidget> {
  late VideoProvider vp;
  @override
  Widget build(BuildContext context) {
    vp = Provider.of<VideoProvider>(context);
    return Container(
      height: widget.h,
      width: widget.w,
      color: Color.fromARGB(255, 218, 218, 207),
      child: Row(
        children: [icons(), bars(), counts()],
      ),
    );
  }

  Widget icons() {
    double h = widget.h;

    double w = widget.w * 0.1;
    return Container(
      height: h,
      width: w,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Icon(Icons.remove_red_eye),
          Icon(Icons.thumb_up),
          Icon(Icons.comment),
          Icon(Icons.radar),
        ],
      ),
    );
  }

  bars() {
    double h = widget.h;

    double w = widget.w;
    double valueCount = 1;

    return Container(
      height: h,
      width: w * 0.7,
      // color: Colors.pink,
      // child: bar(0, w * 0.7, h * 0.25, vp.stats[widget.index].views),
      child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,

        children: [
          bar(0, w * 0.7, h * 0.25, vp.stats[widget.index].views),
          bar(1, w * 0.7, h * 0.25, vp.stats[widget.index].likes),
          bar(2, w * 0.7, h * 0.25, vp.stats[widget.index].comments),
          bar(
              3,
              w * 0.7,
              h * 0.25,
              ((vp.stats[widget.index].likes) /
                      (vp.stats[widget.index].views) *
                      vp.maxno)
                  .toInt()),
        ],
      ),
    );
  }

  counts() {
    double h = widget.h * 0.22;

    double w = widget.w * 0.2;
    double dfact = 2.5;
    return Container(
      height: widget.h,
      width: w,
      // color: Colors.pink.withAlpha(50),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Text(
            Round.getRound(vp.stats[widget.index].views.toDouble()),
            textAlign: TextAlign.right,
            style: TextStyle(
                fontSize: sqrt(h * w) / (dfact), fontWeight: FontWeight.bold),
          ),
          Text(
            Round.getRound(vp.stats[widget.index].likes.toDouble()),
            style: TextStyle(
                fontSize: sqrt(h * w) / (dfact), fontWeight: FontWeight.bold),
          ),
          Text(
            Round.getRound(vp.stats[widget.index].comments.toDouble()),
            style: TextStyle(
                fontSize: sqrt(h * w) / (dfact), fontWeight: FontWeight.bold),
          ),
          Text(
            Round.getRound(((vp.stats[widget.index].likes /
                        vp.stats[widget.index].views) *
                    100)) +
                " %",
            style: TextStyle(
                fontSize: sqrt(h * w) / (dfact), fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  bar(int i, double w, double ha, int count) {
    // double tempmaxno = 1;
    // v l c r
    // switch (i) {
    //   case 0:
    //   tempmaxno = vp.

    //     break;
    //   default:
    // }
    return Container(
      height: ha,
      width: w,

      // color: Colors.green,
      padding: EdgeInsets.all(ha * 0.1),
      child: Stack(children: [
        Align(
          alignment: Alignment.centerLeft,
          child: Container(
            // color: Constants.barColors[i],
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(ha * 0.1),
                gradient: LinearGradient(colors: [
                  Constants.barColors[(i + 2) % 4],
                  Constants.barColors[(i + 2) % 4].withOpacity(0.6)
                ], stops: [
                  0.2,
                  0.6
                ])),
            height: ha,
            width: (count / (vp.maxno)) * w,
          ),
        )
      ]),
   
    );
  }
}
