import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:yt1/Providers/provider.dart';
import 'package:yt1/widgets/video_barchart_widget.dart';
import 'package:yt1/widgets/videoimagename.dart';

class VideoBarchartItem extends StatefulWidget {
  int index;
  VideoBarchartItem(this.index);
  @override
  State<VideoBarchartItem> createState() => _VideoBarchartItemState();
}

late VideoProvider vp;

class _VideoBarchartItemState extends State<VideoBarchartItem> {
  @override
  Widget build(BuildContext context) {
    double h = MediaQuery.of(context).size.height;
    double w = MediaQuery.of(context).size.width;
    vp = Provider.of<VideoProvider>(context);
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      clipBehavior: Clip.antiAlias,
      child: Container(
          height: h * 0.18,
          width: w * 0.9,
          decoration: BoxDecoration(
              color: Color.fromARGB(255, 239, 227, 197),
              borderRadius: BorderRadius.circular(h * 0.01),
              boxShadow: [
                BoxShadow(
                    blurRadius: 1, spreadRadius: 1, offset: Offset(0.51, 0.51))
              ]),
          margin: EdgeInsets.all(w * 0.02),
          child: Column(
            children: [
              Container(
                height: h * 0.03,
                width: w * 1.0,
                child: Center(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: FittedBox(
                      child: Padding(
                        padding: EdgeInsets.all(h * 0.005),
                        child: 
                        vp.stats.length> widget.index ? Text(
                          vp.stats[widget.index].name,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontWeight: FontWeight.bold
                          ),
                        ):const Text(
                         '',
                          textAlign: TextAlign.center,style:  TextStyle(
                            fontWeight: FontWeight.bold
                          ),
                          
                        ) ,
                      ),
                      fit: BoxFit.fitHeight,
                    ),
                  ),
                ),
              ),
              Row(
                children: [
                // Text("dd"),
                // Text("dsss"),
                  VideoImageName(
                    widget.index,
                    h * 0.12,
                    // w * 0.25, 
                    h*0.12*(4/3)
                  ),
                  VideoBarChartWidget(
                    widget.index,
                    h * 0.12,
                    // w * (0.75-0.046), 
                    w*(1-0.046) -  h*0.12*(4/3)
                  )
                ],
              ),
           
              Container(
                height: h * 0.03,
                width: w * 0.9,
       
                child: Center(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: FittedBox(
                      child: Padding(
                        padding: EdgeInsets.all(h * 0.005),
                        child: Text(
                          vp.stats[widget.index].channelName,
                          textAlign: TextAlign.center,
                          style:  TextStyle(
                            fontWeight: FontWeight.bold
                          ),
                        ),
                      ),
                      fit: BoxFit.fitHeight,
                    ),
                  ),
                ),
              ),
            ],
          )),
    );
  }
}
