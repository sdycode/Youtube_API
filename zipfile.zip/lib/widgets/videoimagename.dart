import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../Providers/provider.dart';

class VideoImageName extends StatefulWidget {
  int index;
  double h;
  double w;
  VideoImageName(this.index, this.h, this.w);

  @override
  State<VideoImageName> createState() => _VideoImageNameState();
}

late VideoProvider vp;

class _VideoImageNameState extends State<VideoImageName> {
  @override
  Widget build(BuildContext context) {
    vp = Provider.of<VideoProvider>(context);
    return ClipRRect(
      // 
      
      child: Container(
        height: widget.h,
        width: widget.w,
        // color: Colors.pink.shade100,
        child: Column(
          children: [
            Container(
              color: Color.fromARGB(249, 13, 12, 12),
              height: widget.h ,
              width: widget.w,
              child:
              
              
               Image.network(
                vp.stats[widget.index].imgurl,
                width: widget.w, height: widget.h * 0.5,
                fit: BoxFit.cover,
                loadingBuilder: (context,child, img)=> 
                img== null ? child :
                Container( height: widget.h ,
              width: widget.w,
                  child: 
                  // Shimmer.fromColors(
                   Container(
                         color: Color.fromARGB(250, 102, 98, 100),
                        height: widget.h ,
              width: widget.w,
                    ),
                    // baseColor: Colors.black12,
                    // highlightColor: Colors.white,
                    // loop: 1000,
                  
                ),
              ),
            
            ),
            // Container(
            //   color: Color.fromARGB(1, 185, 204, 211),
            //   height: widget.h * 0.5,
            //   width: widget.w,



            //   child: Text(
            //     vp.maxno.toString()
            //   ),
            // //   child: 
            // //   Text(
            // //     vp.stats[widget.index].name,
            // //     style: TextStyle(
            // //         fontSize: sqrt((widget.h * 0.5 * widget.w * 0.5 * 400)) /
            // //             (vp.stats[widget.index].name.characters.length)),
            // //   ),
            // )
          ],
        ),
      ),
    );
  }
}
