import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:yt1/Providers/provider.dart';
import 'package:yt1/Utils/constants.dart';

import '../Utils/round_no.dart';

class SingleFeatureBarChart extends StatefulWidget {
  double h;
  double w;
  VideoProvider vpsingle;
  SingleFeatureBarChart(this.h, this.w, this.vpsingle, {Key? key})
      : super(key: key);

  @override
  State<SingleFeatureBarChart> createState() => _SingleFeatureBarChartState();
}

class _SingleFeatureBarChartState extends State<SingleFeatureBarChart> {
  final imgw = 0.15;
  final bar = 0.7;
  final text = 0.15;
  // late VideoProvider vp;
  @override
  Widget build(BuildContext context) {
    double h = widget.h;
    double w = widget.w;
    // vp = Provider.of<VideoProvider>(context);

    return Container(
      height: h,
      width: w,
      color: Constants.barColors[widget.vpsingle.chartfeature.index].withOpacity(0.15),
      child: widget.vpsingle.stats.isEmpty
          ? Center(
              child: Text(
                "Search any thing and compare videos in bar charts",
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Constants.barColors[widget.vpsingle.chartfeature.index],
                    fontSize: w * 0.09,
                    fontWeight: FontWeight.bold),
              ),
            )
          : ListView.builder(
              itemCount: widget.vpsingle.stats.length,
              itemBuilder: (c, i) {
                return InkWell(
                    onTap: () {
                      // widget.vpsingle.controller.load(widget.vpsingle.stats[i].videoId);
                      // widget.vpsingle.saveLastVideoId(widget.vpsingle.stats[i].videoId);
                      // widget.vpsingle.initialiseYoutubePlayerController();
                      // widget.vpsingle.changePlayerReadyState(true);
                    },
                    child: singleBar(i, h * 0.1));
              }),
    );
  }

  Widget singleBar(int i, double h) {
    double barw = 1;
    double count = 1;

    switch (widget.vpsingle.chartfeature) {
      case ChartrFeature.view:
        barw = widget.vpsingle.stats[i].views / widget.vpsingle.maxview;
        count = widget.vpsingle.stats[i].views.toDouble();
        break;
      case ChartrFeature.like:
        barw = widget.vpsingle.stats[i].likes / widget.vpsingle.maxlike;
        count = widget.vpsingle.stats[i].likes.toDouble();
        break;
      case ChartrFeature.comment:
        barw = widget.vpsingle.stats[i].comments / widget.vpsingle.maxcomment;
        count = widget.vpsingle.stats[i].comments.toDouble();
        break;

      case ChartrFeature.likeviewratio:
        count = double.parse(
            ((widget.vpsingle.stats[i].likes / widget.vpsingle.stats[i].views) * 100).toStringAsFixed(1));
        barw = (count) / widget.vpsingle.maxlikeviewratio;
        print("maxbarwratio ${count} & ---  ${widget.vpsingle.maxlikeviewratio}");
        break;
      default:
        barw = widget.vpsingle.stats[i].views / widget.vpsingle.maxview;
        count = widget.vpsingle.stats[i].views.toDouble();
    }

    return Container(
      height: h,
      width: widget.w,
      color: Constants.bgColors[widget.vpsingle.chartfeature.index],
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(h * 0.2),
            child: Container(
              width: widget.w * imgw,
              height: h * 0.7,
              child: Image.network(
                widget.vpsingle.stats[i].imgurl,
                // width: widget.w * imgw,
                // height: h*0.7,
                fit: BoxFit.fill,
              ),
            ),
          ),
          Stack(
            children: [
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(h * 0.1),
                ),
                width: widget.w * bar,
                height: h,
                // color: Color.fromARGB(255, i * 10, i * 20, 111),
              ),
              Container(
                width: widget.w * bar * barw * 0.9,
                height: h * 0.6,
                // color:Constants.barColors[widget.vpsingle.chartfeature.index],
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(h * 0.1),
                    gradient: LinearGradient(colors: [
                      Constants.barColors[widget.vpsingle.chartfeature.index],
                      Constants.barColors[widget.vpsingle.chartfeature.index]
                          .withOpacity(0.5)
                    ], stops: [
                      0.2,
                      0.8
                    ])),
                margin: EdgeInsets.only(
                  top: h * 0.28,
                  bottom: h * 0.28,
                  right: widget.w * bar * 0.05,
                  left: widget.w * bar * 0.03,
                ),
                // padding: EdgeInsets.only( right: widget.w * 0.02,
                //   left: widget.w * 0.02,),
              )
            ],
          ),
          Container(
            width: widget.w * text,
            height: h,
            color: Constants.bgColors[widget.vpsingle.chartfeature.index],
            child: Center(
                child: FittedBox(
              child: Text(
                widget.vpsingle.chartfeature == ChartrFeature.likeviewratio
                    ? count.toString() + " % "
                    : Round.getRound(count),
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            )),
          )
        ],
      ),
    );
  }
}
