import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'package:yt1/models/video_info.dart';
import 'package:yt1/models/video_stats.dart';
import 'package:yt1/widgets/playlist_thumbnail.dart';
import 'package:yt1/widgets/video_barchart_item.dart';

import '../models/playlist_model.dart';
import '../widgets/video_item.dart';

enum ChartrFeature { all, view, like, comment, likeviewratio }

class VideoProvider with ChangeNotifier {
  int apikeyindex = 0;
  int bottomindex = 0;

  List<VideoStats> stats = [];
  List<VideoBarchartItem> barchartVideos = [];
  Map<String, List<VideoData>> plMap = {};
  List<PlaylistInfoModel> plListList = [];
  List<PlaylistThumbnail> plSearchListWidgets = [];
  double maxlike = 1;
  double maxcomment = 1;
  double maxview = 1;
  double maxlikeviewratio = 1;

  double maxno = 1;
  int selectedPLIndex = 0;
  bool showPLItems = false;
  ChartrFeature chartfeature = ChartrFeature.all;

  List<String> chartFeatureNames = [
    'All',
    'Views',
    'Likes',
    'Comments',
    'Views / Likes %'
  ];

  get chartFeatureNamesList => chartFeatureNames;

  TextEditingController searchTextCont = TextEditingController();
  TextEditingController searchTextContPlaylist = TextEditingController();
  TextEditingController pllistLinkCont = TextEditingController();
  void setSearchTextCont(String newText) {
    searchTextCont.text = newText;
    notifyListeners();
  }

  void setSearchTextContPL(String newText) {
    searchTextContPlaylist.text = newText;
    notifyListeners();
  }

  void addNewVideoStat(VideoStats videoStats) {
    stats.add(videoStats);
    notifyListeners();
  }

  void addNBarchartVideo(VideoBarchartItem videoBarchartItem) {
    barchartVideos.add(videoBarchartItem);
    notifyListeners();
  }

  void setMaxNo(double maxnum) {
    maxno = maxnum;
    notifyListeners();
  }

  void setMaxLike(double mlike) {
    maxlike = max(maxlike, mlike);
  }

  void setMaxComment(double mcomment) {
    maxcomment = max(maxcomment, mcomment);
    notifyListeners();
  }

  void setMaxView(double mView) {
    maxview = max(maxview, mView);
    notifyListeners();
  }

  void setMaxlikeviewRatio(double mlvratio) {
    maxlikeviewratio = max(maxlikeviewratio, mlvratio);
    notifyListeners();
  }

  void setAllMax() {
    maxno = max(max(maxcomment, maxview), maxlikeviewratio);
    notifyListeners();
  }

  void changeChartFeature(ChartrFeature feature) {
    chartfeature = feature;
    notifyListeners();
  }

  void changeBottomIndex(int i) {
    bottomindex = i;
    notifyListeners();
  }

  void addPLVideotothisMap(String s, VideoData v) {
    if (plMap.containsKey(s)) {
      plMap[s]!.add(v);
    } else {
      plMap[s] = [];
    }

    notifyListeners();
  }

  void resetAllMaxCounters() {
    maxlike = 1;
    maxcomment = 1;
    maxview = 1;
    maxlikeviewratio = 1;

    maxno = 1;
    notifyListeners();
  }

  void addPLListModelToList(PlaylistInfoModel plmodel) {
    plListList.add(plmodel);
    notifyListeners();
  }

  void setSelectedPLIndex(int index) {
    selectedPLIndex = index;
    notifyListeners();
  }

  void setShowPlaylistItems(bool b) {
    showPLItems = b;
    notifyListeners();
  }

  void addplSearchListWidgets(PlaylistThumbnail vd) {
    plSearchListWidgets.add(vd);
    notifyListeners();
  }

  void updateUI() {
    notifyListeners();
  }

  void setPLLinkTextCont(String d) {
    pllistLinkCont.text = d;
    notifyListeners();
  }

  bool isPlayerReady = true;
  void changePlayerReadyState(bool b) {
    isPlayerReady = b;
    notifyListeners();
  }

  
 

  double _volume = 100;
  bool _muted = false;



  


  void changeAPIkeyIndex() {
    apikeyindex += 1;
    apikeyindex = apikeyindex % 4;
    notifyListeners();
  }
}
