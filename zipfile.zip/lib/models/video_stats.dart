class VideoStats {
  String name;
  String duration;
  int likes;
  int views;
  int comments;
  String imgurl;
  String channelName;
  String videoId;
  VideoStats(
      {required this.name,
      required this.duration,
      required this.likes,
      required this.views,
      required this.comments,
      required this.imgurl,
      required this.channelName, 
      
      required this.videoId
      });
}
