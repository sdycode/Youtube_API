// To parse this JSON data, do
//
//     final playlistData = playlistDataFromJson(jsonString);

import 'dart:convert';

PlaylistData playlistDataFromJson(String str) => PlaylistData.fromJson(json.decode(str));

String playlistDataToJson(PlaylistData data) => json.encode(data.toJson());

class PlaylistData {
    PlaylistData({
        required this.kind,
       required this.etag,
       required this.nextPageToken,
       required this.items,
       required this.pageInfo,
    });

    String kind;
    String etag;
    String nextPageToken;
    List<Item> items;
    PageInfo pageInfo;

    factory PlaylistData.fromJson(Map<String, dynamic> json) => PlaylistData(
        kind: json.containsKey('kind') ? json["kind"]: 'kind',
        etag: json.containsKey('etag') ? json["etag"]:'',
        nextPageToken:json.containsKey('nextPageToken') ? json["nextPageToken"]:'',
        items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
        pageInfo: PageInfo.fromJson( json.containsKey('etag') ?  json["pageInfo"]:''),
    );

    Map<String, dynamic> toJson() => {
        "kind": kind,
        "etag": etag,
        "nextPageToken": nextPageToken,
        "items": List<dynamic>.from(items.map((x) => x.toJson())),
        "pageInfo": pageInfo.toJson(),
    };
}

class Item {
    Item({
        required this.kind,
        required this.etag,
        required this.id,
        required this.contentDetails,
    });

    String kind;
    String etag;
    String id;
    ContentDetails contentDetails;

    factory Item.fromJson(Map<String, dynamic> json) => Item(
        kind: json["kind"],
        etag: json["etag"],
        id: json["id"],
        contentDetails: ContentDetails.fromJson(json["contentDetails"]),
    );

    Map<String, dynamic> toJson() => {
        "kind": kind,
        "etag": etag,
        "id": id,
        "contentDetails": contentDetails.toJson(),
    };
}

class ContentDetails {
    ContentDetails({
        required this.videoId,
    });

    String videoId;

    factory ContentDetails.fromJson(Map<String, dynamic> json) => ContentDetails(
        videoId: json["videoId"],
    );

    Map<String, dynamic> toJson() => {
        "videoId": videoId,
    };
}

class PageInfo {
    PageInfo({
       required this.totalResults,
       required this.resultsPerPage,
    });

    int totalResults;
    int resultsPerPage;

    factory PageInfo.fromJson(Map<String, dynamic> json) => PageInfo(
        totalResults: json["totalResults"],
        resultsPerPage: json["resultsPerPage"],
    );

    Map<String, dynamic> toJson() => {
        "totalResults": totalResults,
        "resultsPerPage": resultsPerPage,
    };
}
