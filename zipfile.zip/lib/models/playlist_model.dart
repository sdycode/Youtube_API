class PlaylistInfoModel {
  String playlistid;
  String channelName;
  String title;
  String description;
  String imgUrl;

  PlaylistInfoModel(
    
      
  this.playlistid,
  this.channelName,
  this.title,
  this.description,
  this.imgUrl,
    
  );
}
