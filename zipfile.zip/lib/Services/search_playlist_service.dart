import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:yt1/models/list_playlist.dart' as search;


import '../Utils/constants.dart';
import '../models/list_playlist.dart';
class SearchPlaylistService {
  static String playlistid = "PLPbh-P_C0BzRZsDI2tJvE_wiVRc4_N3GA";
  static const baseUrl = "youtube.googleapis.com";


  static  Future<SearchPlaylistData> getSearchData(String text, String pageToken, int apikeyindex) async {
    // Map<String, String> parameters = {
    //   'part': "contentDetails",
    //   'playlistId': playlistidname,
    //   'maxResults':nos,
    //   'key': API_KEY
    // };
    Map<String, String> parameters = {
      'part': "snippet",
      'q': text,
      'maxResults': '10',
      'type':'Playlist',
      'key': Constants.apikeys[apikeyindex],
      'pageToken': pageToken
    };

    Map<String, String> myheaders = {
      HttpHeaders.contentTypeHeader: "application/json"
      //  HttpHeaders.contentTypeHeader: "application/json"
    };

    Uri uri = Uri.https(baseUrl, "/youtube/v3/search", parameters);

    bool limitover = true;
    if (limitover) {}

    http.Response response =
        await http.get(uri, headers: myheaders).then((value) {
      print("Response is :" + value.body.toString());
     

// video data

      return value;
    });
    print("New Response is :" + response.body.toString());

    // return response;
    // PlaylistData playlistData = playlistDataFromJson(response.body);
    // return playlistData;
 if(response.statusCode == 200){
   SearchPlaylistData videoData = SearchPlaylistData.fromJson(json.decode(response.body));

    return videoData;
 }else{
   search.PageInfo p = search.PageInfo(totalResults: 5, resultsPerPage: 5);
   List<search.Item> l = [];
   return SearchPlaylistData(kind: 'error', etag: "etag", nextPageToken: "nextPageToken", regionCode: "regionCode", pageInfo: p, items: l);
 }
    
  }
}
