import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:yt1/models/search_result.dart' as search;
import 'package:yt1/models/video_info.dart';

import 'package:meta/meta.dart';
import 'dart:convert';

import '../Utils/constants.dart';
import '../models/search_result.dart';

class SearchService {

  static String playlistid = "PLPbh-P_C0BzRZsDI2tJvE_wiVRc4_N3GA";
  static const baseUrl = "youtube.googleapis.com";
  /*
  GET https://youtube.googleapis.com/youtube/v3/playlistItems?part=contentDetails&playlistId=PL92D6833E06037526&key=[YOUR_API_KEY] HTTP/1.1

GET https://youtube.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=50&playlistId=PL92D6833E06037526&key=[YOUR_API_KEY] HTTP/1.1

  */

  /* 
GET https://youtube.googleapis.com/youtube/v3/search?part=snippet&q=srivalli&key=[YOUR_API_KEY] HTTP/1.1

/*
GET https://youtube.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&q=srivalli&key=[YOUR_API_KEY] HTTP/1.1

Authorization: Bearer [YOUR_ACCESS_TOKEN]
Accept: application/json

*/
   
   */
  // static http.Response? latestResponse;
  // static late VideoData videoData;

  static  Future<SearchData> getSearchData(String text, String pageToken, int apikeyindex) async {
    Map<String, String> parameters = {
      'part': "snippet",
      'q': text,
      'maxResults': '10',
      'type': 'video',
      'key': Constants.apikeys[apikeyindex],
      'pageToken': pageToken
    };

    Map<String, String> myheaders = {
      HttpHeaders.contentTypeHeader: "application/json"
    };

    Uri uri = Uri.https(baseUrl, "/youtube/v3/search", parameters);

    bool limitover = true;
    if (limitover) {}

    http.Response response =
    await http.get(uri, headers: myheaders).then((value) {
      print("Response is :" + value.body.toString());


// video data

      return value;
    });
    print("New Response is :" + response.body.toString());

    // return response;
    // PlaylistData playlistData = playlistDataFromJson(response.body);
    // return playlistData;
    if (response.statusCode == 200) {
      SearchData videoData = SearchData.fromJson(json.decode(response.body));

      return videoData;
    } else {
      search.PageInfo p = search.PageInfo(totalResults: 5, resultsPerPage: 5);
      List<search.Item> l = [];
      return SearchData(kind: 'error',
          etag: "etag",
          nextPageToken: "nextPageToken",
          regionCode: "regionCode",
          pageInfo: p,
          items: l);
    }
  }
  }
