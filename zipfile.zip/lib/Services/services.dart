import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:yt1/Utils/constants.dart';
import 'package:yt1/models/playlist_info.dart';
import 'package:yt1/models/video_info.dart';

class Service {

  static String playlistid = "PLPbh-P_C0BzRZsDI2tJvE_wiVRc4_N3GA";
  static const baseUrl = "youtube.googleapis.com";
  /*
  GET https://youtube.googleapis.com/youtube/v3/playlistItems?part=contentDetails&playlistId=PL92D6833E06037526&key=[YOUR_API_KEY] HTTP/1.1

GET https://youtube.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=50&playlistId=PL92D6833E06037526&key=[YOUR_API_KEY] HTTP/1.1

  */

  static Future<PlaylistData> getPlaylistData(
      String playlistidname, String nos, int apikeyindex) async {
    Map<String, String> parameters = {
      'part': "contentDetails",
      'playlistId': playlistidname,
      'maxResults': "25",
      'key': Constants.apikeys[apikeyindex]
    };

    Map<String, String> myheaders = {
      HttpHeaders.contentTypeHeader: "application/json"
    };

    Uri uri = Uri.https(baseUrl, "/youtube/v3/playlistItems", parameters);

    http.Response response = await http.get(uri, headers: myheaders);
    print("Response is PlaylistData :" + response.body.toString());

    PlaylistData playlistData = playlistDataFromJson(response.body);
    return playlistData;
  }

/*
GET https://youtube.googleapis.com/youtube/v3/videos?part=contentDetails%2Csnippet&id=njZeplqhFXI&key=[YOUR_API_KEY] HTTP/1.1
*/
  static Future<VideoData> getVideoInfo(String videoId, int apikeyindex) async {
    Map<String, String> parameters = {
      'part': "contentDetails,snippet,statistics",
      'id': videoId,
      'key': Constants.apikeys[apikeyindex]
    };

    Map<String, String> myheaders = {
      HttpHeaders.contentTypeHeader: "application/json"
    };

    Uri uri = Uri.https(baseUrl, "/youtube/v3/videos", parameters);

    http.Response response = await http.get(uri, headers: myheaders);
    print("Response is  videoData:" + response.body.toString());

    VideoData videoData = videoDataFromJson(response.body);
    return videoData;
  }
}
