// ignore_for_file: avoid_print

import 'package:clipboard/clipboard.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:yt1/Providers/provider.dart';
import 'package:yt1/Services/search_playlist_service.dart';
import 'package:yt1/Services/services.dart';
import 'package:yt1/Utils/sizes.dart';
import 'package:yt1/models/list_playlist.dart';
import 'package:yt1/models/playlist_info.dart';
import 'package:yt1/models/playlist_model.dart';
import 'package:yt1/models/video_info.dart';

import 'package:yt1/widgets/playlist_thumbnail.dart';
import 'package:yt1/widgets/video_item.dart';

import '../Providers/provider.dart';
import '../Utils/showsnackbar.dart';

class PlaylistScreen extends StatefulWidget {
  VideoProvider vppl;
  PlaylistScreen(this.vppl, {Key? key}) : super(key: key);

  @override
  _PlaylistScreenState createState() => _PlaylistScreenState();
}

class _PlaylistScreenState extends State<PlaylistScreen> {
  late SearchPlaylistData searchPlaylistData;
  // late VideoProvider widget.vppl;
  bool quotaExceeded = false;
  final GlobalKey<ScaffoldState> _sckey =  GlobalKey<ScaffoldState>();
  // /-----------
  String valueChoose = "1";
  TextEditingController playlistUrlController = TextEditingController();
  TextEditingController noOfvideosController = TextEditingController();
  String playlistName = "Nothing";
  List<String> NumberList = ['1', '2', '3'];

  String singleVideoDuaration = "-- : -- : --";
  double finalHr = 0, finalMin = 0, finalSec = 0;
  String a =
      "https://images.pexels.com/photos/160472/doll-boy-cheeky-toys-160472.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  List<VideoItem> videos = [];
  List<VideoItem> plSearchItems = [];

  List<String> names = [];
  List<String> durations = [];
  List<String> videoIdList = [];
  List<VideoData> videoDatalist = [];
  late PlaylistData playlistData;
  late VideoData videoData;
  int size = 0;
  bool isLoading = false;
  String totaltime = "H::M::S";
  String name = "name";
  String imgurl =
      "https://images.pexels.com/photos/160472/doll-boy-cheeky-toys-160472.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  String duration = "Press button";
  int h = 0, m = 0, s = 0;
  bool isPlaylistOpen = false;

  String getPlaylistId(String p) {
    print("plidd valuse passe d  " + p);
    String ans = "";
    List<String> l = p.split('=');
    print("plidd le is ${l}");
    ans = l.elementAt(1);
    print("plidd le ansssssssssssssss ${l[1]}");
    return ans;
  }

  getinfo(String playlistidName, String nos) async {
    totaltime = "00:00:00";
    print("  In Info " + playlistidName + " == ");
    // playlistName = getPlaylistId(playlistidName);
    videos.clear();
    names.clear();
    durations.clear();
    videoIdList.clear();
    print(" in videopl : " +
        playlistName +
        "an d  playlistidName -- " +
        playlistidName);
    playlistData = await Service.getPlaylistData(
        playlistidName, nos, widget.vppl.apikeyindex);
    if (playlistData.kind != 'error') {
     
    } else {
      widget.vppl.changeAPIkeyIndex();
    }
    for (int i = 0; i < playlistData.items.length; i++) {
      print(" in : " + playlistData.items[i].contentDetails.videoId);
      videoIdList.add(playlistData.items[i].contentDetails.videoId);
    }

    for (int j = 0; j < videoIdList.length; j++) {
      videoData =
          await Service.getVideoInfo(videoIdList[j], widget.vppl.apikeyindex)
              .then((vdd) {
        if (vdd.kind != 'error') {
        } else {
          widget.vppl.changeAPIkeyIndex();
        }
        if (vdd.items.isNotEmpty) {
          name = vdd.items[0].snippet.title.toString();
          imgurl = vdd.items[0].snippet.thumbnails.high.url;
          print("IMge url " + imgurl);
          duration = vdd.items[0].contentDetails.duration;
          durations.add(duration);
          singleVideoTime(duration);
          duration = singleVideoDuaration;
          widget.vppl
              .addPLVideotothisMap(widget.vppl.selectedPLIndex.toString(), vdd);
          videos.add(VideoItem(
            videoNo: j + 1,
            title: name,
            imgurl: imgurl,
            duration: duration,
            videoId: playlistData.items[j].contentDetails.videoId,
          ));
               calculate();
        }

        return vdd;
      });

      print(" in video : " + name);
    }
    // setState(() {
    //   isPlaylistOpen = true;
    // });

    print("Videos size are  : " + videos.length.toString());
    if (videos.length == playlistData.items.length) {
      print("Completed : ");
      calculate();
      setState(() {
        isLoading = false;
      });
    }
  }

  //   return;
  // }
  @override
  void initState() {
    // SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: []);
    // for (int i = 0; i < 47; i++) {
    //   NumberList.add((4 + i).toString());
    // }

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // widget.vppl = Provider.of<VideoProvider>(context);
    double h = MediaQuery.of(context).size.height;
    double t = MediaQuery.of(context).viewPadding.top;
    double bar = appbar(0).preferredSize.height;

    double w = MediaQuery.of(context).size.width;
    double ha = h - Sizes().sh * 0.08 - 26;
    return WillPopScope(
      onWillPop: () async {
        // print("showPLItems beofre " + isPlaylistOpen.toString());

        if (widget.vppl.showPLItems) {
          // widget.vppl.setShowPlaylistItems(false);
          print("showPLItems " + widget.vppl.showPLItems.toString());
          // setState(() {
          //   isPlaylistOpen = false;
          // });
          return false;
        } else {
          // widget.vppl.updateUI();
          return true;
        }
      },
      child: Scaffold(
          key: _sckey,
          resizeToAvoidBottomInset: true,
          body: Container(
            height: ha,
            width: w,
            color: Color.fromARGB(50, 227, 221, 203),
            child:
            
           
             SingleChildScrollView(
              child: Column(
                children: [
                  searchBox(ha, w),
                  pastePlaylistlinkBox(ha * 0.05, w),
                  widget.vppl.showPLItems ?

                      // isPlaylistOpen
                   playlistItemsList(ha, w)
                      : playlistlist(ha, w),
                  widget.vppl.showPLItems
                      ? totalTimeBox(ha * 0.05, w)
                      : Container(),
                ],
              ),
            ),
          )),
    );
  }


  // buttons(double h, double w) {
  //   return Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
  //     // ElevatedButton(
  //     //     onPressed: () {
  //     //       widget.vppl.changePlayerReadyState(false);
  //     //     },
  //     //     child: Text('Close Player')),
  //     InkWell(
  //       onTap: (){            widget.vppl.changePlayerReadyState(false);
  //       },
  //       child: Icon(Icons.close, color: Colors.red, size: h*0.6,),
  //     ),
  //     InkWell(
  //       onTap: () {
         
  //       },
  //       child: Icon(!widget.vppl.controller.value.isPlaying
  //           ? Icons.pause
  //           : Icons.play_arrow,size: h*0.6,),
  //     ),
  //     totalTimeBox(h, w * 0.4)
  //   ]);
  // }

  calculate() {
    finalHr = 0;
    finalMin = 0;
    finalSec = 0;
    for (int i = 0; i < durations.length; i++) {
      fun(durations[i]);
    }
    if (finalSec > 59) {
      int temp = finalSec ~/ 60;
      //  print(temp);
      finalMin += temp;
      finalSec = finalSec % 60;
    }

    if (finalMin > 59) {
      int temp = finalMin ~/ 60;
      finalHr += temp;
      finalMin = finalMin % 60;
    }
    // print("hr is: $hr \n min is : $min \n sec is : $sec");

    setState(() {
      totaltime = finalHr.toInt().toString() +
          ':' +
          finalMin.toInt().toString() +
          ':' +
          finalSec.toInt().toString();
    });
  }

  void fun(String s) {
    int hr = 0, min = 0, sec = 0;
    int temp = 0, t, cnt = 0, start = 2;

    for (int i = 2; i < s.length; i++) {
      if (s.codeUnitAt(i) >= 48 && s.codeUnitAt(i) <= 57) {
        cnt++;
      } else {
        String currString = s.substring(start, start + cnt);

//             int value =0;
//             geek >> value;
//             cout<<"value is "<<value<<"\n";
        //  print(currString);
        if (s[i] == 'H') {
          finalHr +=
              int.tryParse(currString) != null ? int.parse(currString) : 0;
        } else if (s[i] == 'M') {
          finalMin +=
              int.tryParse(currString) != null ? int.parse(currString) : 0;
        } else {
          finalSec +=
              int.tryParse(currString) != null ? int.parse(currString) : 0;
        }
        start = i + 1;
        cnt = 0;
      }
    }
    singleVideoDuaration = "[ " +
        finalHr.toString() +
        " : " +
        finalMin.toString() +
        " : " +
        finalSec.toString() +
        " ]";
    // print("hr is: $hr \n min is : $min \n sec is : $sec");
  }

  PreferredSizeWidget appbar(double t) {
    return AppBar(title: Text("Youtube Playlist $t"));
  }

  void singleVideoTime(String s) {
    int hr = 0, min = 0, sec = 0;
    int temp = 0, t, cnt = 0, start = 2;
    singleVideoDuaration = s;
    for (int i = 2; i < s.length; i++) {
      if (s.codeUnitAt(i) >= 48 && s.codeUnitAt(i) <= 57) {
        cnt++;
      } else {
        String currString = s.substring(start, start + cnt);

//             int value =0;
//             geek >> value;
//             cout<<"value is "<<value<<"\n";
        //  print(currString);
        if (s[i] == 'H') {
          hr += int.tryParse(currString) != null ? int.parse(currString) : 0;
        } else if (s[i] == 'M') {
          min += int.tryParse(currString) != null ? int.parse(currString) : 0;
        } else {
          sec += int.tryParse(currString) != null ? int.parse(currString) : 0;
        }
        start = i + 1;
        cnt = 0;
      }
    }

    if (sec > 59) {
      int temp = sec ~/ 60;
      //  print(temp);
      min += temp;
      sec = sec % 60;
    }

    if (min > 59) {
      int temp = min ~/ 60;
      hr += temp;
      min = min % 60;
    }
    singleVideoDuaration = "[ " +
        hr.toString() +
        " : " +
        min.toString() +
        " : " +
        sec.toString() +
        " ]";
    // print("hr is: $hr \n min is : $min \n sec is : $sec");
    setState(() {
      
    });
  }

  searchBox(double h, double w) {
    return Padding(
      padding:  EdgeInsets.only(left:w*0.02, right:w*0.02),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [


              // fit: StackFit.expand,

                Container(
                  width: w * 0.8,
                  height: h * 0.05,
                  // margin: EdgeInsets.all(h * 0.01),
                  decoration: BoxDecoration(
                      // border: Border.all(width: 1, color: Colors.black),
                      borderRadius: BorderRadius.circular(h * 0.01)),
                  child: TextField(
                      controller: widget.vppl.searchTextContPlaylist,
                      decoration: InputDecoration(
                        suffixIcon:   IconButton(
                          onPressed: (){
                            widget.vppl.setSearchTextContPL('');

                          },
                    icon: Icon(Icons.close),
                  ), border: OutlineInputBorder(
                        borderSide:  BorderSide(color: Colors.black),
                        borderRadius: BorderRadius.circular(h*0.02),

                        // gapPadding: h*0.01
                      ),
                          hintText: 'Search playlist',
                          // enabledBorder: InputBorder.none,
                          contentPadding: EdgeInsets.all(h * 0.012)),
                      onSubmitted: (d) {
                        widget.vppl.setSearchTextContPL(d);
                        if (widget.vppl.searchTextContPlaylist.text != '' &&
                            widget.vppl.searchTextContPlaylist.text
                                .contains(RegExp(r'[a-zA-z]|\d+'))) {
                          searchPressed();
                        } else {
                          Snack.showSnack(_sckey, 'Please Enter valid text !!!');
                        }
                      },
                      onChanged: (d) {
                        widget.vppl.setSearchTextCont(d);
                      }),




          ),
          Spacer(),
          IconButton(
              onPressed: () {
                if (widget.vppl.searchTextContPlaylist.text != '' &&
                    widget.vppl.searchTextContPlaylist.text
                        .contains(RegExp(r'[a-zA-z]|\d+'))) {
                  searchPressed();
                } else {
                  Snack.showSnack(_sckey, 'Please Enter valid text !!!');
                }
              },
              icon: Padding(
                padding: EdgeInsets.all(0.0),
                child: Icon(Icons.search),
              )),
          Spacer()
        ],
      ),
    );
  }

  void searchPressed() async {
    videos.clear();
    widget.vppl.setShowPlaylistItems(false);
//widget.vppl.searchTextCont.text
    searchPlaylistData = await SearchPlaylistService.getSearchData(
            widget.vppl.searchTextCont.text, '', widget.vppl.apikeyindex)
        .then((SearchPlaylistData currentSearchData) async {
      print(' total result ${currentSearchData.pageInfo.totalResults}');
      if (currentSearchData.kind != 'error') {
        makeVideoList(currentSearchData);
        // for (int i = 0; i < currentSearchData.pageInfo.totalResults ~/ 5; i++) {
        //   String nextPageToken = currentSearchData.nextPageToken;
        //   SearchData nextSearchData =
        //       await SearchService.getSearchData(tcont.text, nextPageToken);
        //   if (nextSearchData.kind == 'error') {
        //     setState(() {
        //       quotaExceeded = true;
        //     });
        //     break;
        //   }

        //   print(nextPageToken);
        //   makeVideoList(nextSearchData);
        // }
      } else {
        // setState(() {
        widget.vppl.changeAPIkeyIndex();
        // quotaExceeded = true;
        // });
      }

      return currentSearchData;
    });
  }

  void makeVideoList(SearchPlaylistData currentSearchData) async {
    // stats.clear();
    widget.vppl.plSearchListWidgets.clear();
    widget.vppl.stats.clear();
    widget.vppl.barchartVideos.clear();
    widget.vppl.resetAllMaxCounters();
    widget.vppl.plListList.clear();
    for (int j = 0; j < currentSearchData.items.length; j++) {
      // VideoData vdata =
      //     await Service.getVideoInfo(currentSearchData.items[j].id);
      String playlistid = currentSearchData.items[j].id.playlistId;
      String title = currentSearchData.items[j].snippet.title;
      String imgUrl = currentSearchData.items[j].snippet.thumbnails.high.url;
      String channelName = currentSearchData.items[j].snippet.channelTitle;
      String description = currentSearchData.items[j].snippet.description;
      widget.vppl.addPLListModelToList(PlaylistInfoModel(
          playlistid, channelName, title, description, imgUrl));
      // String durationHMT = vdata.items[0].contentDetails.duration;
      // singleVideoTime(durationHMT);
      // VideoStats videoStats = VideoStats(
      //     name: name,
      //     duration: singleVideoDuaration,
      //     likes: int.parse(vdata.items[0].statistics.likeCount),
      //     views: int.parse(vdata.items[0].statistics.viewCount),
      //     comments: int.parse(
      //       vdata.items[0].statistics.commentCount,
      //     ),
      //     imgurl: imgurl,
      //     channelName: vdata.items[0].snippet.channelTitle);
      // widget.vppl.setMaxComment(double.parse(vdata.items[0].statistics.commentCount));
      // widget.vppl.setMaxLike(double.parse(vdata.items[0].statistics.likeCount));
      // widget.vppl.setMaxView(double.parse(vdata.items[0].statistics.viewCount));
      // double ratio = double.parse(vdata.items[0].statistics.likeCount) /
      //     double.parse(vdata.items[0].statistics.viewCount) *
      //     100;
      // widget.vppl.setMaxlikeviewRatio(ratio);
      // print("maxratioo ${ratio} and ${widget.vppl.maxlikeviewratio}");

      // widget.vppl.addNewVideoStat(videoStats);
      // widget.vppl.addNBarchartVideo(VideoBarchartItem(j));

      print("IMge url " + imgurl);
      PlaylistThumbnail v = PlaylistThumbnail(
        j,
        // videoNo: j + 1,
        // title: title,
        // imgurl: imgUrl,
        // duration: singleVideoDuaration,
      );
      widget.vppl.addplSearchListWidgets(v);
      print(" in video : " + name);
    }
    widget.vppl.setAllMax();
    // setState(() {});
  }

  playlistlist(double ha, double w) {
    return Container(
        height: ha * 0.88,
        width: w,
        // color: Colors.red,
        margin: EdgeInsets.only(bottom: ha * 0.01 * 0),
        child: ListView.builder(
          itemBuilder: (_, index) => InkWell(
              onTap: () {
                widget.vppl.setSelectedPLIndex(index);
                widget.vppl.changePlayerReadyState(false);

                getinfo(
                    widget.vppl.plListList[index].playlistid, 10.toString());
                widget.vppl.setShowPlaylistItems(true);
              },
              child: widget.vppl.plSearchListWidgets.elementAt(index)),
          itemCount: widget.vppl.plSearchListWidgets.length,
        ));
  }

  playlistItemsList(double ha, double w) {
    return Container(
        height: ha * (0.88 - 0.06),
        width: w,
        // color: Colors.pink,
        child: ListView.builder(
          itemBuilder: (_, i) => InkWell(
              onTap: () {
                

              },
              child: videos.elementAt(i)),
          itemCount: videos.length,
        ));
  }

  pastePlaylistlinkBox(double ha, double w) {
    return Container(
      height: ha,
      width: w,
      padding:  EdgeInsets.only(left:w*0.02, right:w*0.02),

      // color: Colors.pink,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // fit: StackFit.expand,

          Container(
            width: w * 0.65 - ha * 0.002,
            height: ha,

            decoration: BoxDecoration(

                borderRadius: BorderRadius.circular(ha * 0.31)),
            child: TextField(
                controller: widget.vppl.pllistLinkCont,
                decoration: InputDecoration(

                    hintText: '   Paste Playlist URL ...',
                    contentPadding: EdgeInsets.all(ha * 0.1588),
                    suffixIcon:   IconButton(
                    onPressed: (){
                      widget.vppl.setPLLinkTextCont('');

            },
              icon: Icon(Icons.close),
            ), border: OutlineInputBorder(
        borderSide:  BorderSide(color: Colors.black),
        borderRadius: BorderRadius.circular(ha*0.32),

        // gapPadding: h*0.01
      ),
                ),


                onSubmitted: (d) {
                  // widget.vppl.setSearchTextContPL(d);
                  // widget.vppl.setShowPlaylistItems(false);

                  // searchPressed();
                },
                onChanged: (d) {
                  // widget.vppl.setPLLinkTextCont(d);
                  // setState(() {});
                }),
          ),


          Container(
            // width: w * 0.1,
            color: Colors.transparent,
            child: Align(
              alignment: Alignment.center,
              child: InkWell(
                  onTap: () {
                    FlutterClipboard.paste().then((value) {
                      widget.vppl.pllistLinkCont.text = value;
                      // print("pasted code is:" + code.toString());
                      print("list controller" + playlistUrlController.text);
                    });
                  },
                  child: Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(ha * 0.25),
                        color: Colors.orange.shade400),
                    padding: EdgeInsets.all(ha * 0.142),
                    child: Text(
                      'Paste',
                      style: TextStyle(fontSize: ha * 0.35),
                    ),
                  )),
            ),
          ),
          Container(
              width: w * 0.1,
              color: Colors.transparent,
              child: Align(
                alignment: Alignment.center,
                child: InkWell(
                  onTap: () {
                    // searchPressed();
                    if (widget.vppl.pllistLinkCont.text
                        .contains("playlist?list=")) {
                      String plid =
                          getPlaylistId(widget.vppl.pllistLinkCont.text);
                      print("plidd is " +
                          plid +
                          " and text is " +
                          widget.vppl.pllistLinkCont.text);
                      getinfo(plid, '10');
                      widget.vppl.setShowPlaylistItems(true);
                    } else {
                      Snack.showSnack(
                          _sckey, 'Please Enter valid playlist link !');
                    }
                    // if (widget.vppl.pllistLinkCont.text != '' &&
                    //     widget.vppl.pllistLinkCont.text
                    //         .contains(RegExp(r'[a-zA-z]|\d+'))) {
                    //   if (widget.vppl.pllistLinkCont.text.contains('=') &&
                    //       widget.vppl.pllistLinkCont.text.length > 2) {
                    //     String plid = getPlaylistId(widget.vppl.pllistLinkCont.text);
                    //     print("plidd is " +
                    //         plid +
                    //         " and text is " +
                    //         widget.vppl.pllistLinkCont.text);
                    //     getinfo(plid, '10');
                    //     widget.vppl.setShowPlaylistItems(true);
                    //   } else {
                    //     Snack.showSnack(_sckey, 'Please Enter valid text !!!');
                    //   }
                    // } else {
                    //   Snack.showSnack(_sckey, 'Please Enter valid text !!!');
                    // }
                  },
                  child: Container(
                      padding: EdgeInsets.all(ha * 0.142),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(ha * 0.25),
                          color: Color.fromARGB(255, 90, 74, 235)),
                      child: Text(
                        'Get',
                        style: TextStyle(
                          fontSize: ha * 0.35,
                          color: Colors.white,
                        ),
                      )),
                ),
              )),
        ],
      ),
    );
  }

  Widget totalTimeBox(double ha, double w) {
    return
        // SingleChildScrollView(
        //   child: Text(widget.vppl.pllistLinkCont.text),
        // );
        Container(
      width: w,
      height: ha,
      // color: Color.fromARGB(255, 236, 177, 156),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Container(
            height: ha,
            width: w * 0.6,
            child: FittedBox(
              child: Text("Total time : "),
              fit: BoxFit.contain,
            ),
          ),
          Container(
              height: ha,
              width: w * 0.4,
              child: FittedBox(
                child: Text(totaltime),
                fit: BoxFit.contain,
              ))
        ],
      ),
    );
  }
}

/*



    // Container(
        //   // margin: const EdgeInsets.all(5),
        //   // *(1- Sizes.bottomH)
        //   height:ha,
        //   width: w,
        //   color: Colors.pink,
        //   child: SingleChildScrollView(
        //     child: Column(
        //       crossAxisAlignment: CrossAxisAlignment.center,
        //       children: [
        //         Container(
        //           width: MediaQuery.of(context).size.width * 0.8,
        //           child: Row(
        //             mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        //             children: [
        //               SizedBox(
        //                 //height: 50,
        //                 width: MediaQuery.of(context).size.width * 0.4,
        //                 child: TextField(
        //                   textAlign: TextAlign.center,
        //                   decoration: const InputDecoration(
        //                     hintText: "Paste playlist URL..",
        //                   ),
        //                   controller: playlistUrlController,
        //                 ),
        //               ),
        //               SizedBox(
        //                 // width: 40,
        //                 //  height: 50,
        //                 width: MediaQuery.of(context).size.width * 0.2,

        //                 child: DropdownButton<String>(
        //                   style: const TextStyle(
        //                     fontSize: 25,
        //                     color: Colors.black,
        //                   ),
        //                   value: valueChoose,
        //                   onChanged: (String? newValue) {
        //                     setState(() {
        //                       valueChoose = newValue!;
        //                     });
        //                     for (int i = 0; i < NumberList.length; i++) {
        //                       // print(i.toString() +
        //                       //     " current =  " +
        //                       //     newValue.toString() +
        //                       //     " Lang = " +
        //                       //     LocalizationService.languages[i] +
        //                       //     "local is" +
        //                       //     localList[i].toString());
        //                       if (NumberList[i] == newValue) {
        //                         // print("app lang is " + localList[i].toString());
        //                         // Get.updateLocale(localList[i]);
        //                         setState(() {
        //                           noOfvideosController.text = NumberList[i];
        //                         });
        //                         print(NumberList[i] + "is selected");

        //                         // p = "codeSent".tr;
        //                       }
        //                     }
        //                   },
        //                   isExpanded: true,
        //                   isDense: true,
        //                   items: NumberList.map<DropdownMenuItem<String>>(
        //                       (String value) {
        //                     return DropdownMenuItem<String>(
        //                       alignment: Alignment.center,
        //                       value: value,
        //                       child: SizedBox(
        //                         child: Text(
        //                           value,
        //                           textDirection: TextDirection.ltr,
        //                           textAlign: TextAlign.center,
        //                         ),
        //                         width: MediaQuery.of(context).size.width - 100,
        //                         height: 40,
        //                       ),
        //                     );
        //                   }).toList(),
        //                 ),
        //                 // TextField(
        //                 //   decoration: const InputDecoration(
        //                 //     hintText: "No of videos ..",
        //                 //   ),
        //                 //   textAlign: TextAlign.center,
        //                 //   keyboardType: TextInputType.number,
        //                 //   controller: noOfvideosController,
        //                 // ),
        //               ),
        //               // Container(height: 60, width: 60, child: Text(playlistName)),
        //             ],
        //           ),
        //         ),
        //         const SizedBox(
        //           height: 10,
        //         ),
        //         // Text(durations.length.toString()),
        //         Row(
        //           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        //           children: [
        //             ElevatedButton(
        //               onPressed: () {
        //                 setState(() {
        //                   final code = FlutterClipboard.paste().then((value) {
        //                     playlistUrlController.text = value;
        //                     // print("pasted code is:" + code.toString());
        //                     print("list controller" + playlistUrlController.text);
        //                   });
        //                   // playlistUrlController.text = code.toString();
        //                 });
        //               },
        //               child: const Text(
        //                 'Paste Link',
        //                 style: TextStyle(color: Colors.white),
        //               ),
        //               style: ElevatedButton.styleFrom(
        //                 primary: Colors.red,
        //               ),
        //             ),
        //             ElevatedButton(
        //               onPressed: () {
        //                 if (noOfvideosController.text.isEmpty ||
        //                     playlistUrlController.text.isEmpty) {
        //                   noOfvideosController.text = "1";
        //                   if (playlistUrlController.text.isEmpty) {
        //                     showDialog(
        //                         context: context,
        //                         builder: (ctx) {
        //                           return AlertDialog(
        //                             title: const Text('Something missing !!!'),
        //                             content: SingleChildScrollView(
        //                               child: ListBody(
        //                                 children: const <Widget>[
        //                                   Text('Please paste playlist URL'),
        //                                 ],
        //                               ),
        //                             ),
        //                           );
        //                         });
        //                   }
        //                 }
        //                 if (!playlistUrlController.text.isEmpty) {
        //                   setState(() {
        //                     isLoading = true;
        //                   });
        //                   getinfo(playlistUrlController.text,
        //                       noOfvideosController.text);
        //                 }
        //               },
        //               child: const Text("Get PlayList",
        //                   style: TextStyle(
        //                     color: Colors.white,
        //                   )),
        //               style:
        //                   ElevatedButton.styleFrom(primary: Colors.purpleAccent),
        //             ),
        //           ],
        //         ),
        //         Container(
        //             height: 35,
        //             child: isLoading
        //                 ? const CircularProgressIndicator()
        //                 : const Text(
        //                     "Paste link in above box and click Get Playlist Button")),
        //         Container(
        //             height: MediaQuery.of(context).size.height * 0.425,
        //             child: SafeArea(
        //                 child: ListView.builder(
        //               itemBuilder: (_, index) => videos.elementAt(index),
        //               itemCount: videos.length,
        //             ))),
        //         SizedBox(
        //           width: MediaQuery.of(context).size.width * 0.9,
        //           child: Row(
        //             mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        //             children: [
        //               SizedBox(
        //                 width: 180,
        //                 //  height: ,
        //                 child: ElevatedButton(
        //                   onPressed: () {
        //                     calculate();
        //                   },
        //                   child: const Text("Total Time"),
        //                   style: ElevatedButton.styleFrom(
        //                     primary: Colors.orangeAccent,
        //                   ),
        //                 ),
        //               ),
        //               SizedBox(
        //                 width: 120,
        //                 // height: 25,
        //                 child: Center(
        //                     child: Text(
        //                   totaltime,
        //                   style: TextStyle(
        //                       fontSize: 25, fontWeight: FontWeight.bold),
        //                 )),
        //               ),
        //             ],
        //           ),
        //         )
        //       ],
        //     ),
        //   ),
        // ),

      
*/
