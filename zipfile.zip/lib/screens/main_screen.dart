import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:yt1/Providers/provider.dart';
import 'package:yt1/Utils/sizes.dart';
import 'package:yt1/screens/playlist_screen.dart';
import 'package:yt1/screens/search_screen.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int bottomindex = 0;
  @override
  void initState() {
    SystemChrome.setPreferredOrientations(
        [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
    // SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: []);
    super.initState();
  }

  late VideoProvider vp;
  @override
  void dispose() {
  
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double h = MediaQuery.of(context).size.height;
    double w = MediaQuery.of(context).size.width;
    vp = Provider.of<VideoProvider>(
      context,
    );
    List<Widget> tabs = [SearchScreen(vp), PlaylistScreen(vp)];

    print("vpp index  " + vp.bottomindex.toString());
    return WillPopScope(
      onWillPop: () async {
        // print("showPLItems beofre " + isPlaylistOpen.toString());

        if (vp.showPLItems) {
          vp.setShowPlaylistItems(false);
          print("showPLItems " + vp.showPLItems.toString());
          // setState(() {
          //   isPlaylistOpen = false;
          // });
          return false;
        } else {
          // vp.updateUI();
          return true;
        }
      },
      child: SafeArea(
        child: Scaffold(
          bottomNavigationBar:
              MediaQuery.of(context).orientation == Orientation.landscape
                  ? null
                  : bottomNavigationBarCustom(),
          resizeToAvoidBottomInset: true,
          body: Container(
            height: h - MediaQuery.of(context).viewPadding.top - 40,
            width: w,
            child: tabs[bottomindex],
          ),
        ),
      ),
    );
  }

  Widget bottomNavigationBarCustom() {
    return Container(
      // color: Colors.red,
      height: Sizes().sh * 0.08,
      child: BottomNavigationBar(
        backgroundColor: Color.fromARGB(255, 17, 1, 81).withAlpha(255),
        selectedItemColor: Colors.blue,
        unselectedItemColor: Color.fromARGB(255, 229, 192, 235),
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Container(
                height: Sizes().sh * 0.04,
                child: ClipRect(
                    child: bottomindex == 0
                        ? Icon(Icons.search)
                        : Icon(
                            Icons.search,
                            color: Color.fromARGB(255, 104, 133, 168),
                          ))),
            label: 'Video',
          ),
          BottomNavigationBarItem(
            icon: Container(
                height: Sizes().sh * 0.04,
                child: ClipRect(
                    child: bottomindex == 1
                        ? Icon(Icons.playlist_play_sharp)
                        : Icon(
                            Icons.playlist_add_rounded,
                            color: Color.fromARGB(255, 104, 133, 168),
                          ))),
            label: 'Playlist',
          ),
        ],
        currentIndex: bottomindex,
        onTap: (n) {
          setState(() {
            bottomindex = n;
          });
          if (n == 1) {}
          // vp.disposeIt();
          // vp.initialiseYoutubePlayerController();
          // vp.changeBottomIndex(n);

          // setState(() {
          // bottomTabIndex = n;
          // if (n == 0) {
          //   // vp.initialiseYoutubePlayerController();
          // }
          // });
        },
      ),
    );
  }
}
