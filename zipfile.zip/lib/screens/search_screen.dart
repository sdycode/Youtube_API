import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart';
import 'package:provider/provider.dart';

import 'package:clipboard/clipboard.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:yt1/Providers/provider.dart';
import 'package:yt1/Services/search_playlist_service.dart';
import 'package:yt1/Services/search_services.dart';
import 'package:yt1/Services/services.dart';
import 'package:yt1/Utils/showsnackbar.dart';
import 'package:yt1/Utils/sizes.dart';
import 'package:yt1/models/list_playlist.dart';
import 'package:yt1/models/playlist_info.dart';
import 'package:yt1/models/playlist_model.dart';
import 'package:yt1/models/search_result.dart';
import 'package:yt1/models/video_info.dart';

import 'package:yt1/models/video_stats.dart';
import 'package:yt1/widgets/playlist_thumbnail.dart';
import 'package:yt1/widgets/single_feature_chart.dart';
import 'package:yt1/widgets/video_barchart_item.dart';
import 'package:yt1/widgets/video_item.dart';

import '../Services/services.dart';
import '../Utils/constants.dart';
import 'package:package_info_plus/package_info_plus.dart';

class SearchScreen extends StatefulWidget {
  VideoProvider vps;
  SearchScreen(this.vps, {Key? key}) : super(key: key);

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  String title = "title";
  List<VideoItem> videos = [];
  List<VideoStats> stats = [];
  String singleVideoDuaration = "-- : -- : --";
  late SearchData searchData;
  bool quotaExceeded = false;
  // Future<Response?>? re;

  // bool _isPlayerReady = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
        _initPackageInfo();

  }
  PackageInfo _packageInfo = PackageInfo(
    appName: 'Unknown',
    packageName: 'Unknown',
    version: 'Unknown',
    buildNumber: 'Unknown',
    buildSignature: 'Unknown',
  );
Future<void> _initPackageInfo() async {
    final info = await PackageInfo.fromPlatform();
    setState(() {
      _packageInfo = info;
    });
  }
  
  @override
  void dispose() {
    super.dispose();
  }

  // late VideoProvider vp;

  @override
  Widget build(BuildContext context) {
    double h = MediaQuery.of(context).size.height;
    double w = MediaQuery.of(context).size.width;
    // vp = Provider.of<VideoProvider>(context);
    double circle = h * 0.03;
    print("widget.vps.isPlayerReady " + widget.vps.isPlayerReady.toString());
    return Scaffold(
      key: _scaffoldKey,
      body:  Container(
              height: h * 0.92,
              // 1 - Sizes.bottomH),
              width: w,
              color: Color.fromARGB(255, 239, 240, 226).withAlpha(210),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [

                    searchBox(h*0.06, w*0.80),

                    // Padding(
                    //   padding:  EdgeInsets.only(left:w*0.02, right:w*0.02),
                    //   child: Row(
                    //     mainAxisAlignment: MainAxisAlignment.spaceAround,
                    //     children: [
                    //
                    //
                    //           // fit: StackFit.expand,
                    //
                    //       //       Container(
                    //       //         width: w * 0.8,
                    //       //         height: h * 0.04,
                    //       //         // margin: EdgeInsets.all(h * 0.01),
                    //       //         // padding: EdgeInsets.all(h * 0.01),
                    //       //         decoration: BoxDecoration(
                    //       //             color: Colors.amber.withAlpha(50),
                    //       //
                    //       //             // border: Border.all(),
                    //       //             borderRadius:
                    //       //                 BorderRadius.circular(h * 0.02)),
                    //       //         child: Center(
                    //       //           child: TextField(
                    //       //               controller: widget.vps.searchTextCont,
                    //       //
                    //       //               decoration: InputDecoration(
                    //       //                 contentPadding: EdgeInsets.all(h*0.01),
                    //       //
                    //       //                   suffixIcon: IconButton(
                    //       //                   onPressed: (){
                    //       //                     setState(() {
                    //       //                       widget.vps.setSearchTextCont('');
                    //       //                     });
                    //       //                     widget.vps.stats.clear();
                    //       //                     widget.vps.barchartVideos.clear();
                    //       //                   },
                    //       //                   icon: Icon(Icons.close),
                    //       //                 ),
                    //       //                 border: OutlineInputBorder(
                    //       //                     borderSide:  BorderSide(color: Colors.black),
                    //       //                     borderRadius: BorderRadius.circular(h*0.02),
                    //       //
                    //       //                     // gapPadding: h*0.01
                    //       //                 ),
                    //       //                   hintText: 'Search anything',
                    //       //                   // contentPadding:
                    //       //                   //     EdgeInsets.all(h * 0.01)
                    //       //                       ),
                    //       //               onSubmitted: (d) {
                    //       //                 if (d != '' &&
                    //       //                     d.contains(RegExp(r'[a-zA-z]|\d+'))) {
                    //       //                   searchPressed();
                    //       //                 } else {
                    //       //                   Snack.showSnack(_scaffoldKey,
                    //       //                       'Please Enter valid text !!!');
                    //       //                 }
                    //       //               },
                    //       //               onChanged: (d) {
                    //       //                 setState(() {});
                    //       //               }),
                    //       //         ),
                    //       //
                    //       //
                    //       //
                    //       // ),
                    //       //
                    //       IconButton(
                    //           onPressed: () {
                    //             if (widget.vps.searchTextCont.text != '' &&
                    //                 widget.vps.searchTextCont.text
                    //                     .contains(RegExp(r'[a-zA-z]|\d+'))) {
                    //               searchPressed();
                    //             } else {
                    //               Snack.showSnack(_scaffoldKey,
                    //                   'Please Enter valid text !!!');
                    //             }
                    //           },
                    //           icon: Padding(
                    //             padding: EdgeInsets.all(0.0),
                    //             child: Icon(Icons.search),
                    //           ))
                    //     ],
                    //   ),
                    // ),

                    quotaExceeded
                        ? Container(
                            height: h * 0.8,
                            width: w,
                            child: Center(
                              child: Text(
                                "Quota Exceeded",
                                // style: GoogleFonts.aBeeZee(),
                                // style: TextStyle(
                                //     fontSize: 30, fontWeight: FontWeight.bold),
                              ),
                            ),
                          )
                        : Container(
                                color: Color.fromARGB(255, 240, 247, 230),
                                height: h * 0.695,
                                width: w,
                                child: widget.vps.chartfeature ==
                                        ChartrFeature.all
                                    ? widget.vps.barchartVideos.isEmpty
                                        ? Center(
                                            child: Text(
                                              "Search any thing and compare videos in bar charts",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: Constants.barColors[
                                                      widget.vps.chartfeature
                                                          .index],
                                                  fontSize: w * 0.09,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          )
                                        : (ListView.builder(
                                            itemCount: widget
                                                .vps.barchartVideos.length,
                                            itemBuilder: (c, i) {
                                              return InkWell(
                                                  onTap: () {
                                            
                                                  },
                                                  child: widget
                                                      .vps.barchartVideos[i]);
                                            }))
                                    : SingleFeatureBarChart(
                                        h * 0.728, w, widget.vps),
                              ),
                    Container(
                      height: h * 0.05,
                      // color: Colors.pink,
                      child: Padding(
                        padding: EdgeInsets.all(h * 0.01),
                        child: FittedBox(
                          fit: BoxFit.fitWidth,
                          child: Text(
                        // _packageInfo.version+"/"+   _packageInfo.buildNumber
                            widget.vps.chartFeatureNames[
                              widget.vps.chartfeature.index]
                              ),
                        ),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        InkWell(
                          onTap: () {
                            // _controller.load('3e540RFL5-Y');
                            widget.vps.changeChartFeature(ChartrFeature.all);
                          },
                          child: CircleAvatar(
                            backgroundColor:
                                widget.vps.chartfeature == ChartrFeature.all
                                    ? Constants
                                        .bgColors[widget.vps.chartfeature.index]
                                    : Constants.circleNOTSelectColor,
                            foregroundColor: Colors.black,
                            radius: circle,
                            child: FittedBox(child: Icon(Icons.all_inbox)),
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            widget.vps.changeChartFeature(ChartrFeature.view);
                          },
                          child: CircleAvatar(
                              foregroundColor: Colors.black,
                              backgroundColor: widget.vps.chartfeature ==
                                      ChartrFeature.view
                                  ? Constants
                                      .bgColors[widget.vps.chartfeature.index]
                                  : Constants.circleNOTSelectColor,
                              radius: circle,
                              child: Icon(Icons.remove_red_eye)),
                        ),
                        InkWell(
                          onTap: () {
                            widget.vps.changeChartFeature(ChartrFeature.like);
                          },
                          child: CircleAvatar(
                            backgroundColor:
                                widget.vps.chartfeature == ChartrFeature.like
                                    ? Constants
                                        .bgColors[widget.vps.chartfeature.index]
                                    : Constants.circleNOTSelectColor,
                            foregroundColor: Colors.black,
                            radius: circle,
                            child: Icon(Icons.thumb_up),
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            widget.vps
                                .changeChartFeature(ChartrFeature.comment);
                          },
                          child: CircleAvatar(
                            backgroundColor:
                                widget.vps.chartfeature == ChartrFeature.comment
                                    ? Constants
                                        .bgColors[widget.vps.chartfeature.index]
                                    : Constants.circleNOTSelectColor,
                            foregroundColor: Colors.black,
                            radius: circle,
                            child: Container(child: Icon(Icons.comment)),
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            widget.vps.changeChartFeature(
                                ChartrFeature.likeviewratio);
                          },
                          child: CircleAvatar(
                            backgroundColor: widget.vps.chartfeature ==
                                    ChartrFeature.likeviewratio
                                ? Constants
                                    .bgColors[widget.vps.chartfeature.index]
                                : Constants.circleNOTSelectColor,
                            foregroundColor: Colors.black,
                            radius: circle,
                            child: Container(child: Icon(Icons.radar)),
                          ),
                        ),
                      ],
                    )
                    // : Container(
                    //     height: h * 0.8,
                    //     width: w,
                    //     child: ListView.builder(
                    //         itemCount: videos.length,
                    //         itemBuilder: (c, i) {
                    //           return videos[i];
                    //         }),
                    //   ),
                    // Text(tcont.text),
                    // Text(title),
                    // Container(
                    //     height: MediaQuery.of(context).size.height * 0.535,
                    //     child: SafeArea(
                    //         child: ListView.builder(
                    //       itemBuilder: (_, index) => videos.elementAt(index),
                    //       itemCount: videos.length,
                    //     ))),
                  ],
                ),
              ),
            ),
    );
  }

  searchBox(double h, double w) {
    return Container(
      // color: Colors.red,
      child: Padding(
        padding:  EdgeInsets.only(left:w*0.02, right:w*0.02),
        // padding: EdgeInsets.all(h*0.1),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [


            // fit: StackFit.expand,

            Container(
              width: w * 0.8,
              height: h *0.8,
              // margin: EdgeInsets.all(h * 0.01),
              decoration: BoxDecoration(
                // color: Colors.blue,
                // border: Border.all(width: 1, color: Colors.black),
                  borderRadius: BorderRadius.circular(h * 0.01)),
              child: Center(
                child: TextField(
                    controller: widget.vps.searchTextCont,
                    decoration: InputDecoration(
                        suffixIcon:   IconButton(
                          onPressed: (){
                            setState(() {
                              widget.vps.setSearchTextCont('');
                            });
                            widget.vps.stats.clear();
                            widget.vps.barchartVideos.clear();
                          },
                          icon: Icon(Icons.close),
                        ), border: OutlineInputBorder(
                      borderSide:  BorderSide(color: Colors.black),
                      borderRadius: BorderRadius.circular(h*0.4),

                      // gapPadding: h*0.01
                    ),
                        hintText: 'Search video',
                        // enabledBorder: InputBorder.none,
                        contentPadding: EdgeInsets.only(left:h * 0.12)),
                    onSubmitted: (d) {
                      if (d != '' &&
                          d.contains(RegExp(r'[a-zA-z]|\d+'))) {
                        searchPressed();
                      } else {
                        Snack.showSnack(_scaffoldKey,
                            'Please Enter valid text !!!');
                      }
                    },
                    onChanged: (d) {
                      setState(() {

                      });
                    }),
              ),




            ),
            Spacer(),
            IconButton(
                onPressed: () {
                  if (widget.vps.searchTextCont.text != '' &&
                      widget.vps.searchTextCont.text
                          .contains(RegExp(r'[a-zA-z]|\d+'))) {
                    searchPressed();
                  } else {
                    Snack.showSnack(_scaffoldKey,
                        'Please Enter valid text !!!');
                  }
                },
                icon: Padding(
                  padding: EdgeInsets.all(0.0),
                  child: Icon(Icons.search),
                )),
            Spacer()
          ],
        ),
      ),
    );
  }

  void singleVideoTime(String s) {
    int hr = 0, min = 0, sec = 0;
    int temp = 0, t, cnt = 0, start = 2;

    for (int i = 2; i < s.length; i++) {
      if (s.codeUnitAt(i) >= 48 && s.codeUnitAt(i) <= 57) {
        cnt++;
      } else {
        String currString = s.substring(start, start + cnt);

//             int value =0;
//             geek >> value;
//             cout<<"value is "<<value<<"\n";
        //  print(currString);
        if (s[i] == 'H' && int.tryParse(currString) != null) {
          hr += int.parse(currString);
        } else if (s[i] == 'M' && int.tryParse(currString) != null) {
          min += int.parse(currString);
        } else if (int.tryParse(currString) != null) {
          sec += int.parse(currString);
        }
        start = i + 1;
        cnt = 0;
      }
    }

    if (sec > 59) {
      int temp = sec ~/ 60;
      //  print(temp);
      min += temp;
      sec = sec % 60;
    }

    if (min > 59) {
      int temp = min ~/ 60;
      hr += temp;
      min = min % 60;
    }
    singleVideoDuaration = "[ " +
        hr.toString() +
        " : " +
        min.toString() +
        " : " +
        sec.toString() +
        " ]";
    // print("hr is: $hr \n min is : $min \n sec is : $sec");
  }

  searchPressed() async {
    videos.clear();

    searchData = await SearchService.getSearchData(
            widget.vps.searchTextCont.text, '', widget.vps.apikeyindex)
        .then((SearchData currentSearchData) async {
      print(' total result ${currentSearchData.pageInfo.totalResults}');
      if (currentSearchData.kind != 'error') {
        makeVideoList(currentSearchData);
        // for (int i = 0; i < currentSearchData.pageInfo.totalResults ~/ 5; i++) {
        //   String nextPageToken = currentSearchData.nextPageToken;
        //   SearchData nextSearchData =
        //       await SearchService.getSearchData(tcont.text, nextPageToken);
        //   if (nextSearchData.kind == 'error') {
        //     setState(() {
        //       quotaExceeded = true;
        //     });
        //     break;
        //   }

        //   print(nextPageToken);
        //   makeVideoList(nextSearchData);
        // }
      } else {
        setState(() {
          widget.vps.changeAPIkeyIndex();

          // quotaExceeded = true;
        });
      }

      return currentSearchData;
    });
  }

  void makeVideoList(SearchData currentSearchData) async {
    stats.clear();
    widget.vps.stats.clear();
    widget.vps.barchartVideos.clear();
    widget.vps.resetAllMaxCounters();
    for (int j = 0; j < currentSearchData.items.length; j++) {
      VideoData vdata = await Service.getVideoInfo(
          currentSearchData.items[j].id.videoId, widget.vps.apikeyindex);
      if (vdata.kind != 'error') {
      } else {
        widget.vps.changeAPIkeyIndex();
      }
      String name = currentSearchData.items[j].snippet.title;
      String imgurl = currentSearchData.items[j].snippet.thumbnails.high.url;

      String durationHMT = vdata.items[0].contentDetails.duration;
      singleVideoTime(durationHMT);
      VideoStats videoStats = VideoStats(
          name: name,
          duration: singleVideoDuaration,
          likes: int.parse(vdata.items[0].statistics.likeCount),
          views: int.parse(vdata.items[0].statistics.viewCount),
          comments: int.parse(
            vdata.items[0].statistics.commentCount,
          ),
          imgurl: imgurl,
          channelName: vdata.items[0].snippet.channelTitle,
          videoId: currentSearchData.items[j].id.videoId);
      widget.vps
          .setMaxComment(double.parse(vdata.items[0].statistics.commentCount));
      widget.vps.setMaxLike(double.parse(vdata.items[0].statistics.likeCount));
      widget.vps.setMaxView(double.parse(vdata.items[0].statistics.viewCount));
      double ratio = double.parse(vdata.items[0].statistics.likeCount) /
          double.parse(vdata.items[0].statistics.viewCount) *
          100;
      widget.vps.setMaxlikeviewRatio(ratio);
      print("maxratioo ${ratio} and ${widget.vps.maxlikeviewratio}");

      widget.vps.addNewVideoStat(videoStats);
      widget.vps.addNBarchartVideo(VideoBarchartItem(j));

      print("IMge url " + imgurl);

      videos.add(VideoItem(
        videoNo: j + 1,
        title: name,
        imgurl: imgurl,
        duration: singleVideoDuaration,
        videoId: currentSearchData.items[j].id.videoId,
      ));
      print(" in video : " + name);
    }
    widget.vps.setAllMax();
    // setState(() {});
  }


}
/*

sample json data used to convert into models


{
  "kind": "youtube#searchListResponse",
  "etag": "j7y7lsGdm6foH3LxCFfpnK-A1zs",
  "nextPageToken": "CAIQAA",
  "regionCode": "IN",
  "pageInfo": {
    "totalResults": 1000000,
    "resultsPerPage": 2
  },
  "items": [
    {
      "kind": "youtube#searchResult",
      "etag": "pbaAu7nT-biFkYFMYZRy-usD7Zw",
      "id": {
        "kind": "youtube#video",
        "videoId": "8EihuEbqiBA"
      },
      "snippet": {
        "publishedAt": "2022-02-24T06:32:22Z",
        "channelId": "UCF4Wxdo3inmxP-Y59wXDsFw",
        "title": "[🔴LIVE] &quot;러시아, 우크라이나 침공&quot;  현지 실시간 상황과 뉴스 | 우크라이나의 평화를 기원합니다! - MBC NEWS",
        "description": "우크라이나의 평화를 기원합니다! 전쟁이 끝나고 평화가 오는 그 날까지, \"끝까지라이브\" 함께합니다. 외신을 통해 들어오는 ...",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/8EihuEbqiBA/default_live.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/8EihuEbqiBA/mqdefault_live.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/8EihuEbqiBA/hqdefault_live.jpg",
            "width": 480,
            "height": 360
          }
        },
        "channelTitle": "MBCNEWS",
        "liveBroadcastContent": "live",
        "publishTime": "2022-02-24T06:32:22Z"
      }
    },
    {
      "kind": "youtube#searchResult",
      "etag": "8yITjJMnHfh5t3LBDbiwuFdcuB8",
      "id": {
        "kind": "youtube#video",
        "videoId": "89uDnmFtvoA"
      },
      "snippet": {
        "publishedAt": "2016-07-07T12:30:48Z",
        "channelId": "UCW0ZdZjp_1NjVi7FQeuvOZw",
        "title": "ILPF recupera pastagem e triplica produtividade",
        "description": "Vídeo mostra pesquisa com ILPF realizada na Embrapa Pecuária Sudeste em São Carlos (SP).",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/89uDnmFtvoA/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/89uDnmFtvoA/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/89uDnmFtvoA/hqdefault.jpg",
            "width": 480,
            "height": 360
          }
        },
        "channelTitle": "Embrapa",
        "liveBroadcastContent": "none",
        "publishTime": "2016-07-07T12:30:48Z"
      }
    }
  ]
}

*/
