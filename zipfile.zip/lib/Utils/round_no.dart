class Round {
  static String getRound(double no) {
    String ans = no.toInt().toString();
    if (no < 1000) {
      return ans;
    } else if (no >= 1000 && no < 100000) {
      ans = (no / 1000).toInt().toString() + " K";
      return ans;
    } else if (no >= 100000 && no < 10000000) {
      ans = (no / 100000).toInt().toString() + " L";
      return ans;
    } else {
      ans = (no / 10000000).toInt().toString() + " Cr";
      return ans;
    }
  }

}
