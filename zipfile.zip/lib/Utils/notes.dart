

// New Response is :
// {
//    "error": {
//      "code": 403,
//      "message": "The request cannot be completed because you have exceeded your \u003ca href=\"/youtube/v3/getting-started#quota\"\u003equota\u003c/a\u003e.",
//      "errors": [
//        {
//          "message": "The request cannot be completed because you have exceeded your \u003ca href=\"/youtube/v3/getting-started#quota\"\u003equota\u003c/a\u003e.",
//          "domain": "youtube.quota",
//          "reason": "quotaExceeded"
//        }
//      ]
//    }
//  }