import 'package:flutter/material.dart';

class Constants {
  static const apikeys = [
    
  ];

  static const barColors = [
    Color.fromARGB(255, 58, 24, 212),
    Color.fromARGB(255, 64, 73, 244),
    Color.fromARGB(255, 232, 49, 153),
    Color.fromARGB(255, 81, 172, 11),
    Color.fromARGB(255, 180, 23, 237),
  ];

  static const bgColors = [
    Color.fromARGB(255, 122, 196, 228),
    Color.fromARGB(255, 195, 204, 231),
    Color.fromARGB(255, 240, 190, 220),
    Color.fromARGB(255, 220, 248, 210),
    Color.fromARGB(255, 240, 210, 240),
  ];

  static const circleSelectColor = Color.fromARGB(255, 228, 219, 119);
  static const circleNOTSelectColor = Color.fromARGB(255, 236, 231, 178);
}
