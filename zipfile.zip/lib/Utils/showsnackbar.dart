import 'package:flutter/material.dart';

class Snack{
  static showSnack( GlobalKey<ScaffoldState> key, String text ){
 key.currentState!.showSnackBar( SnackBar(
        content:  Text(text), 
          action: SnackBarAction(
    label: 'Dismiss',
    textColor: Colors.yellow,
    onPressed: () {
        key.currentState!.hideCurrentSnackBar();
    //  Navigator.of(context).pop();
    },)
    ));
  }
}