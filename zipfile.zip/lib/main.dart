import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:yt1/Providers/provider.dart';
import 'package:yt1/screens/main_screen.dart';


void main() {
  //   SystemChrome.setPreferredOrientations([
  //   DeviceOrientation.portraitUp,
  //   DeviceOrientation.portraitDown
  // ]);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (c)=> VideoProvider())
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Flutter Demo',
        theme: ThemeData(
       
          primarySwatch: Colors.lime,
        ),
        home:  const MainScreen(),
      ),
    );
  }
}
